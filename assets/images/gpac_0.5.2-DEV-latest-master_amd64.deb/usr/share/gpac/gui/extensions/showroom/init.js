
my_ext = {
    whoami: "GPAC-GUI-Extension",
    name: "Showroom",
    icon: "osmo.bt",
    author: "JeanLF",
    description: "GPAC demonstrations",
    url: "http://gpac.io/",
    execjs: ["showroom.js"],
    autostart: false,
    config_id: "Showroom",
    requires_gl: false,
    version_major: 1,
    version_minor: 0
};

